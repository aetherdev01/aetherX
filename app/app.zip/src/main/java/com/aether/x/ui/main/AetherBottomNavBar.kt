package com.aether.x.ui.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.x.ui.components.LiquidBottomTab
import com.aether.x.ui.components.LiquidBottomTabs
import com.aether.x.ui.components.NAV_MIN_BLUR_DP
import com.aether.x.ui.components.blurRadiusFor
import com.aether.x.ui.components.liquidTabTint
import com.aether.x.ui.components.rememberAetherLiquidBackdrop
import com.aether.x.ui.theme.LocalAetherPalette
import com.aether.x.ui.theme.LocalAetherStyle
import com.aether.x.ui.theme.Spacing
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import dev.chrisbanes.haze.HazeState

/** Tinggi navbar. Kapsul = tinggi ini - 8dp (inset 4dp). */
private val NavBarHeight: Dp = 56.dp

/** Navigation item model retained for all existing call sites. */
data class AetherNavItem(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val accent: Color,
)

/**
 * AetherX bottom navigation rendered with the LiquidBottomTabs implementation from
 * Kyant0/AndroidLiquidGlass. The Haze argument is retained for source compatibility.
 */
@Composable
fun AetherBottomNavBar(
    items: List<AetherNavItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") hazeState: HazeState? = null,
    contentBackdrop: Backdrop? = null,
) {
    if (items.isEmpty()) return

    val palette = LocalAetherPalette.current
    val selectedState = rememberUpdatedState(selectedIndex.coerceIn(0, items.lastIndex))
    val selectedReader = remember { { selectedState.value } }
    val style = LocalAetherStyle.current
    val baseBackdrop = rememberAetherLiquidBackdrop()
    // Latar + konten layar yang scroll di belakang navbar -> kaca navbar mem-blur warna/bentuk
    // elemen di belakangnya (selalu ter-blur, tidak tajam).
    val backdrop = if (contentBackdrop != null) {
        rememberCombinedBackdrop(baseBackdrop, contentBackdrop)
    } else {
        baseBackdrop
    }
    val stripBlurDp = maxOf(blurRadiusFor(style.blur.coerceIn(0f, 1f)) * 0.8f, NAV_MIN_BLUR_DP * 0.8f)

    Box(modifier = modifier.fillMaxWidth()) {
        // Gradient blur di belakang navbar: blur + warna latar makin pekat ke bawah, memudar ke
        // atas tanpa tepi keras.
        Box(
            modifier = Modifier
                .matchParentSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    drawRect(
                        brush = Brush.verticalGradient(
                            0f to Color.Transparent,
                            0.6f to Color.Black,
                        ),
                        blendMode = BlendMode.DstIn,
                    )
                }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { RectangleShape },
                    effects = { blur(stripBlurDp.dp.toPx()) },
                    onDrawSurface = {
                        drawRect(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, palette.bg.copy(alpha = 0.45f)),
                            ),
                        )
                    },
                ),
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .fillMaxWidth()
                .padding(vertical = Spacing.sm),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .padding(horizontal = Spacing.xxl + Spacing.md)
                    .widthIn(max = 380.dp)
                    .fillMaxWidth()
                    .height(NavBarHeight),
            ) {
                LiquidBottomTabs(
                    selectedTabIndex = selectedReader,
                    onTabSelected = onSelect,
                    backdrop = backdrop,
                    tabsCount = items.size,
                    modifier = Modifier.fillMaxSize(),
                    barHeight = NavBarHeight,
                ) {
                    items.forEachIndexed { index, item ->
                        LiquidBottomTab(onClick = { onSelect(index) }) {
                            // Warna dasar textSecondary; crossfade ke accent mengikuti kapsul (fase draw).
                            Column(
                                modifier = Modifier.liquidTabTint(index, palette.accent.copy(alpha = 1f)),
                                verticalArrangement = Arrangement.spacedBy(1.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.label,
                                    tint = palette.textSecondary.copy(alpha = 1f),
                                    modifier = Modifier.size(20.dp),
                                )
                                Text(
                                    text = item.label,
                                    color = palette.textSecondary.copy(alpha = 1f),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 9.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
