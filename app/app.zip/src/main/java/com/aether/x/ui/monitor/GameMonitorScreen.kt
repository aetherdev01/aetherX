package com.aether.x.ui.monitor

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aether.x.core.monitor.GameSession
import com.aether.x.core.monitor.GameSessionRepository
import com.aether.x.ui.components.SectionCard
import com.aether.x.ui.components.aetherCardSurface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import com.aether.x.core.locale.str
import com.aether.x.R

@Composable
fun GameMonitorScreen(
    rootGranted: Boolean,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    LaunchedEffect(context.applicationContext) {
        GameSessionRepository.initialize(context.applicationContext)
    }
    val sessions by GameSessionRepository.sessions.collectAsStateWithLifecycle()
    var expandedGame by remember { mutableStateOf<String?>(null) }
    var expandedSession by remember { mutableStateOf<String?>(null) }
    var sessionToDelete by remember { mutableStateOf<GameSession?>(null) }
    val active = sessions.firstOrNull { it.endedAtMs == null }
    val groupedSessions = sessions.groupBy { it.packageName }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        SectionCard(title = str(R.string.game_monitor_game_monitor_otomatis), watermarkIcon = Icons.Outlined.MonitorHeart) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (rootGranted) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                ) {
                    Text(
                        text = if (rootGranted) str(R.string.game_monitor_root_tersedia) else str(R.string.game_monitor_root_dibutuhkan),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (rootGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    )
                }
                Text(
                    text = if (active != null) str(R.string.game_monitor_sedang_merekam_sesi_game) else str(R.string.game_monitor_menunggu_game_dibuka),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
            Text(
                text = if (rootGranted) {
                    str(R.string.game_monitor_game_yang_dikenali_dari_katalog)
                } else {
                    str(R.string.game_monitor_berikan_akses_root_melalui_magisk)
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (active != null) {
                Text(
                    text = str(R.string.game_monitor_game_aktif, active.gameName, formatDuration(active.durationMs)),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }

        if (active != null) {
            SectionCard(title = str(R.string.game_monitor_fps_sesi_aktif), watermarkIcon = Icons.Outlined.Speed) {
                val fpsPoints = active.samples.mapNotNull { it.fps?.toFloat() }
                RealtimeLineChart(
                    values = fpsPoints,
                    maxValue = maxOf(60f, fpsPoints.maxOrNull() ?: 60f),
                    lineColor = MaterialTheme.colorScheme.primary,
                )
                when {
                    fpsPoints.isEmpty() -> Text(
                        str(R.string.game_monitor_mengumpulkan_data_fps_jika_belum),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    fpsPoints.size < 2 -> Text(
                        str(R.string.game_monitor_first_sample_help),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    text = str(R.string.game_monitor_rata_rata_min_maks, valueOrDash(active.averageFps, " FPS"), valueOrDash(active.minFps, " FPS"), valueOrDash(active.maxFps, " FPS")),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                StatsGrid(session = active)
                if (active.currentFps != null && active.currentFps < 30) {
                    Text(
                        text = str(R.string.game_monitor_fps_terlalu_rendah_peringatan_telah),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }

        SectionCard(title = str(R.string.game_monitor_riwayat_game), watermarkIcon = Icons.Outlined.History) {
            if (groupedSessions.isEmpty()) {
                Text(
                    text = if (rootGranted) str(R.string.game_monitor_history_empty_root) else str(R.string.game_monitor_riwayat_masih_kosong_setelah_akses),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                groupedSessions.forEach { (packageName, gameSessions) ->
                    val latest = gameSessions.first()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    expandedGame = if (expandedGame == packageName) null else packageName
                                    expandedSession = null
                                }
                                .padding(vertical = 5.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                GameAppIcon(packageName = packageName, gameName = latest.gameName)
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(3.dp),
                                ) {
                                    Text(
                                        text = latest.gameName,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                    Text(
                                        text = str(R.string.game_monitor_sesi_terakhir, gameSessions.size, formatDate(latest.startedAtMs)),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Text(
                                    text = if (expandedGame == packageName) str(R.string.game_monitor_tutup) else str(R.string.game_monitor_detail),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Text(
                                text = str(R.string.game_monitor_fps_avg_terendah_tertinggi, valueOrDash(latest.averageFps, ""), valueOrDash(latest.minFps, ""), valueOrDash(latest.maxFps, "")),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (expandedGame == packageName) {
                            gameSessions.forEach { session ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aetherCardSurface(shape = RoundedCornerShape(14.dp)),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Transparent,
                                    tonalElevation = 0.dp,
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                expandedSession = if (expandedSession == session.id) null else session.id
                                            }
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(7.dp),
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(
                                                    text = formatDate(session.startedAtMs),
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                )
                                                Text(
                                                    text = "${formatDuration(session.durationMs)} · ${if (session.endedAtMs == null) str(R.string.game_monitor_session_running) else str(R.string.game_monitor_session_completed)}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                            Text(
                                                text = if (expandedSession == session.id) str(R.string.game_monitor_sembunyikan) else str(R.string.game_monitor_lihat_data),
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary,
                                            )
                                            if (session.endedAtMs != null) {
                                                IconButton(onClick = { sessionToDelete = session }) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Delete,
                                                        contentDescription = str(R.string.game_monitor_hapus_rekaman, session.gameName),
                                                        tint = MaterialTheme.colorScheme.error,
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = str(R.string.game_monitor_avg_min_max, valueOrDash(session.averageFps, " FPS"), valueOrDash(session.minFps, " FPS"), valueOrDash(session.maxFps, " FPS")),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        if (expandedSession == session.id) {
                                            val fpsPoints = session.samples.mapNotNull { it.fps?.toFloat() }
                                            Text(str(R.string.game_monitor_grafik_fps), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
                                            RealtimeLineChart(
                                                values = fpsPoints,
                                                maxValue = maxOf(60f, fpsPoints.maxOrNull() ?: 60f),
                                                lineColor = MaterialTheme.colorScheme.primary,
                                            )
                                            Text(
                                                text = str(R.string.game_monitor_avg_min_maks, valueOrDash(session.averageFps, " FPS"), valueOrDash(session.minFps, " FPS"), valueOrDash(session.maxFps, " FPS")),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                            StatsGrid(session = session)
                                            if (fpsPoints.isEmpty()) {
                                                Text(str(R.string.game_monitor_tidak_ada_sampel_fps_valid), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            } else if (fpsPoints.size < 2) {
                                                Text(str(R.string.game_monitor_sampel_tambahan_diperlukan_untuk_membent), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Text(
                                                text = str(R.string.game_monitor_paket, session.packageName),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        sessionToDelete?.let { session ->
            AlertDialog(
                onDismissRequest = { sessionToDelete = null },
                title = { Text(str(R.string.game_monitor_hapus_rekaman_2)) },
                text = { Text(str(R.string.game_monitor_rekaman_pada_akan_dihapus_permanen, session.gameName, formatDate(session.startedAtMs))) },
                confirmButton = {
                    TextButton(onClick = {
                        GameSessionRepository.deleteSession(session.id)
                        if (expandedSession == session.id) expandedSession = null
                        sessionToDelete = null
                    }) { Text(str(R.string.game_monitor_hapus)) }
                },
                dismissButton = {
                    TextButton(onClick = { sessionToDelete = null }) { Text(str(R.string.membership_logout_cancel)) }
                },
            )
        }
    }
}

@Composable
private fun GameAppIcon(packageName: String, gameName: String) {
    val context = LocalContext.current
    val iconBitmap = remember(packageName) {
        runCatching {
            context.packageManager.getApplicationIcon(packageName)
                .toBitmap(width = 96, height = 96)
                .asImageBitmap()
        }.getOrNull()
    }
    Surface(
        modifier = Modifier.size(46.dp),
        shape = RoundedCornerShape(13.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
    ) {
        if (iconBitmap != null) {
            Image(
                bitmap = iconBitmap,
                contentDescription = str(R.string.game_monitor_ikon, gameName),
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(5.dp),
            )
        } else {
            Icon(
                imageVector = Icons.Outlined.SportsEsports,
                contentDescription = str(R.string.game_monitor_ikon, gameName),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(10.dp),
            )
        }
    }
}

@Composable
private fun StatsGrid(session: GameSession) {
    val currentOrLast = if (session.endedAtMs == null) str(R.string.game_monitor_sekarang) else str(R.string.game_monitor_akhir)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = str(R.string.game_monitor_performa_utama),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        MetricRow(
            Metric("FPS $currentOrLast", valueOrDash(session.currentFps, " FPS")),
            Metric(str(R.string.game_monitor_fps_rata_rata), valueOrDash(session.averageFps, " FPS")),
        )
        MetricRow(
            Metric(str(R.string.game_monitor_fps_terendah), valueOrDash(session.minFps, " FPS")),
            Metric(str(R.string.game_monitor_fps_tertinggi), valueOrDash(session.maxFps, " FPS")),
        )
        MetricRow(
            Metric(str(R.string.game_monitor_cpu_rata_rata), valueOrDash(session.averageCpuPercent, "%")),
            Metric(str(R.string.game_monitor_cpu_maksimum), valueOrDash(session.maxCpuPercent, "%")),
        )
        MetricRow(
            Metric(str(R.string.game_monitor_gpu_rata_rata), valueOrDash(session.averageGpuPercent, "%")),
            Metric(str(R.string.game_monitor_gpu_maksimum), valueOrDash(session.maxGpuPercent, "%")),
        )
        val hasTemperature = session.temperatureStartC != null || session.currentTemperatureC != null || session.maxTemperatureC != null
        if (hasTemperature) {
            Text(
                text = str(R.string.game_monitor_suhu_perangkat),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            MetricRow(
                Metric(str(R.string.game_monitor_suhu, currentOrLast), valueOrDash(session.currentTemperatureC?.roundToInt(), "°C")),
                Metric(str(R.string.game_monitor_suhu_maksimum), valueOrDash(session.maxTemperatureC?.roundToInt(), "°C")),
            )
            if (session.temperatureRiseC != null) {
                MetricRow(
                    Metric(str(R.string.game_monitor_kenaikan_suhu), valueOrDash(session.temperatureRiseC?.roundToInt(), "°C")),
                    Metric(str(R.string.game_monitor_drop_di_bawah_30_fps), str(R.string.game_monitor_kali, session.lowFpsCount)),
                )
            }
        } else {
            MetricRow(
                Metric(str(R.string.game_monitor_drop_di_bawah_30_fps), str(R.string.game_monitor_kali, session.lowFpsCount)),
                Metric("GPU clock", valueOrDash(session.currentGpuFreqMhz?.roundToInt(), str(R.string.game_monitor_mhz))),
            )
        }
    }
}

private data class Metric(val label: String, val value: String)

@Composable
private fun MetricRow(first: Metric, second: Metric) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricTile(first.label, first.value, Modifier.weight(1f))
        MetricTile(second.label, second.value, Modifier.weight(1f))
    }
}

@Composable
private fun MetricTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.aetherCardSurface(shape = RoundedCornerShape(13.dp)),
        shape = RoundedCornerShape(13.dp),
        color = Color.Transparent,
        tonalElevation = 0.dp,
    ) {
        Column(modifier = Modifier.padding(horizontal = 11.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

private fun valueOrDash(value: Int?, suffix: String): String = value?.let { "$it$suffix" } ?: "—"
private fun formatGb(valueMb: Long?): String = valueMb?.let { String.format(Locale.getDefault(), "%.1f GB", it / 1024f) } ?: "—"
private fun formatDate(time: Long): String = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(time))
private fun formatDuration(millis: Long): String {
    val totalSeconds = millis.coerceAtLeast(0L) / 1000L
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return when {
        hours > 0 -> "${hours}j ${minutes}m"
        minutes > 0 -> "${minutes}m ${seconds}d"
        else -> "${seconds}d"
    }
}
