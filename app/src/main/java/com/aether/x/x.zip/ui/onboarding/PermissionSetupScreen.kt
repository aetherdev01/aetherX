package com.aether.x.ui.onboarding

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aether.x.R
import com.aether.x.core.adb.AdbConnectionState
import com.aether.x.core.permission.PrivilegeBackend
import com.aether.x.core.permission.PrivilegeManager
import com.aether.x.core.permission.RequestFailureReason
import com.aether.x.core.permission.RequestFeedback
import com.aether.x.core.permission.RequestState
import com.aether.x.ui.components.AdbPairingCard
import com.aether.x.ui.components.PermissionMethodCard
import com.aether.x.ui.theme.AccentBlue
import com.aether.x.ui.theme.AccentGreen
import com.aether.x.ui.theme.AccentGreenContainer
import com.aether.x.ui.theme.AccentRed
import com.aether.x.ui.theme.BgVoid
import com.aether.x.ui.theme.OnAccentBlue
import com.aether.x.ui.theme.Spacing
import com.aether.x.ui.theme.StrokeSubtle
import com.aether.x.ui.theme.SurfaceCardAlt
import com.aether.x.ui.theme.TextMuted
import com.aether.x.ui.theme.TextPrimary
import com.aether.x.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Layar izin akses — REWORK TOTAL TAMPILAN (lihat perintah rework: "lebih
 * rapi, pakai layar slide, lebih ketat harus semua fitur aktif, tambahkan
 * permission baru kalo dibutuhkan, ada peringatan DWYOR kernel").
 *
 * SEBELUMNYA: satu halaman scroll panjang berisi SEMUA kartu izin
 * sekaligus (ADB/Root, Write Settings, Overlay, Notifications), dan hanya
 * ADB ATAU Root yang benar-benar wajib — tiga izin pendukung lainnya
 * murni opsional ("Izin Tambahan", bisa dilewati begitu saja).
 *
 * SEKARANG: [HorizontalPager] 5 halaman, SATU fokus per halaman —
 * (1) ADB/Root, (2) Write Settings, (3) Overlay, (4) Notifications,
 * (5) Peringatan Kernel (DWYOR, acknowledgment saja, bukan izin sistem).
 * SEMUA EMPAT IZIN (halaman 1-4) sekarang WAJIB granted sebelum bisa
 * lanjut ke halaman berikutnya — tombol "Lanjut" per halaman nonaktif
 * sampai syarat halaman itu terpenuhi. [requireAccessToContinue] = false
 * (dipakai layar "Kelola Akses" dari Pengaturan, BUKAN alur onboarding
 * awal) tetap membiarkan navigasi bebas maju-mundur tanpa mengunci,
 * karena di konteks itu pengguna mungkin memang datang untuk MENCABUT
 * izin, bukan melengkapinya — mengunci maju di sana hanya akan
 * menjebak pengguna.
 *
 * Swipe MUNDUR (ke halaman yang sudah dilewati) selalu bebas — hanya
 * swipe MAJU yang dikunci selama [requireAccessToContinue] = true DAN
 * halaman saat ini belum terpenuhi syaratnya, lewat
 * [LockedForwardPagerNestedScrollConnection] & validasi di tombol Lanjut.
 *
 * Tidak ada permission Android baru yang perlu dideklarasikan di
 * AndroidManifest.xml untuk rework ini — WRITE_SETTINGS, SYSTEM_ALERT_WINDOW,
 * dan POST_NOTIFICATIONS (tiga izin yang sekarang diwajibkan) SEMUANYA
 * sudah dideklarasikan sebelumnya untuk fitur overlay crosshair/FPS
 * monitor & notifikasi pairing ADB yang sudah ada; rework ini murni
 * mengubah alur & keharusan di sisi UI, bukan menambah permission sistem.
 */
@Composable
fun PermissionSetupScreen(
    onContinue: () -> Unit,
    requireAccessToContinue: Boolean = true,
) {
    val context = LocalContext.current
    val status by PrivilegeManager.status.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    // --- Syarat tiap halaman -------------------------------------------
    val accessSatisfied = status.hasAccess
    val writeSettingsSatisfied = status.writeSettingsGranted
    val overlaySatisfied = status.overlayGranted
    val notificationsSatisfied = status.notificationsGranted

    // Peringatan Kernel (halaman terakhir) BUKAN izin sistem — murni
    // acknowledgment pengguna sekali per proses layar ini (state lokal,
    // bukan disimpan permanen: setiap kali layar ini dibuka lagi,
    // termasuk dari "Kelola Akses", pengguna diminta membaca &
    // mencentang ulang, karena ini peringatan keselamatan perangkat yang
    // pantas ditegaskan lagi tiap kali, bukan sekadar formalitas satu kali
    // seumur hidup app).
    var kernelWarningAcknowledged by remember { mutableStateOf(false) }

    val pageSatisfied = listOf(
        accessSatisfied,
        writeSettingsSatisfied,
        overlaySatisfied,
        notificationsSatisfied,
        kernelWarningAcknowledged,
    )
    val pageCount = pageSatisfied.size

    // requireAccessToContinue = false ("Kelola Akses" dari Pengaturan):
    // TIDAK ada penguncian navigasi sama sekali — halaman ini dipakai
    // untuk mencabut/mengelola izin yang sudah ada, bukan untuk
    // menyelesaikan setup, jadi mengunci maju di sini kontraproduktif.
    val allSatisfiedOnEntry = requireAccessToContinue &&
        (accessSatisfied && writeSettingsSatisfied && overlaySatisfied && notificationsSatisfied)

    val pagerState = rememberPagerState(pageCount = { pageCount })

    val canContinue = !requireAccessToContinue || pageSatisfied.all { it }

    // Setiap hasil aksi permintaan izin (gagal ATAU berhasil) SELALU
    // ditampilkan lewat Snackbar di sini, mengonsumsi PrivilegeManager.events
    // — tidak ada lagi kegagalan yang diam-diam tidak memberi tahu pengguna.
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        PrivilegeManager.events.collect { feedback ->
            val message = when (feedback) {
                is RequestFeedback.Granted -> when (feedback.backend) {
                    PrivilegeBackend.ADB -> context.getString(R.string.permission_feedback_adb_granted)
                    PrivilegeBackend.ROOT -> context.getString(R.string.permission_feedback_root_granted)
                    PrivilegeBackend.NONE -> null
                }
                is RequestFeedback.Failed -> when (feedback.reason) {
                    RequestFailureReason.ADB_WIRELESS_DEBUGGING_OFF -> context.getString(R.string.permission_feedback_adb_wireless_debugging_off)
                    RequestFailureReason.ADB_AUTO_DISCOVERY_TIMEOUT -> context.getString(R.string.permission_feedback_adb_auto_discovery_timeout)
                    RequestFailureReason.ADB_PAIRING_CODE_INVALID_OR_EXPIRED -> context.getString(R.string.permission_feedback_adb_pairing_invalid)
                    RequestFailureReason.ADB_HOST_UNREACHABLE -> context.getString(R.string.permission_feedback_adb_host_unreachable)
                    RequestFailureReason.ADB_CONNECT_AFTER_PAIRING_FAILED -> context.getString(R.string.permission_feedback_adb_connect_after_pairing_failed)
                    RequestFailureReason.ADB_SHELL_REJECTED_NEEDS_REPAIR -> context.getString(R.string.permission_feedback_adb_shell_rejected)
                    RequestFailureReason.ADB_UNKNOWN -> context.getString(R.string.permission_feedback_adb_unknown)
                    RequestFailureReason.ADB_ALREADY_IN_PROGRESS -> context.getString(R.string.permission_feedback_adb_in_progress)
                    RequestFailureReason.ROOT_DENIED_OR_UNAVAILABLE -> context.getString(R.string.permission_feedback_root_denied)
                    RequestFailureReason.ROOT_ALREADY_IN_PROGRESS -> context.getString(R.string.permission_feedback_root_in_progress)
                }
            }
            message?.let { snackbarHostState.showSnackbar(it) }
        }
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) {
        PrivilegeManager.refreshSupportingPermissions(context)
    }

    // Cek ulang izin overlay/write-settings/notifikasi/ADB/root tiap kali
    // layar ini kembali ke foreground (mis. setelah pengguna kembali dari
    // halaman Pengaturan Wireless debugging/Overlay/dsb).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                PrivilegeManager.refreshSupportingPermissions(context)
                PrivilegeManager.refreshAll()
                PrivilegeManager.adoptExistingGrantIfNoPreference(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        PrivilegeManager.refreshSupportingPermissions(context)
    }

    LaunchedEffect(status.adbGranted, status.rootGranted) {
        PrivilegeManager.adoptExistingGrantIfNoPreference(context)
    }

    // FITUR BARU — auto-advance: begitu syarat halaman SAAT INI baru
    // terpenuhi (mis. pengguna baru saja berhasil pairing ADB, atau baru
    // kembali dari Pengaturan Overlay dengan izin diberikan), pindah
    // otomatis ke halaman berikutnya SETELAH jeda singkat — supaya
    // pengguna tidak perlu menekan "Lanjut" secara manual tiap kali
    // barusan saja mengizinkan sesuatu. Hanya berlaku maju satu langkah
    // (tidak melompat berkali-kali), dan HANYA saat requireAccessToContinue
    // (alur "Kelola Akses" tetap manual sepenuhnya, tidak auto-advance).
    LaunchedEffect(pageSatisfied, pagerState.currentPage) {
        if (!requireAccessToContinue) return@LaunchedEffect
        val currentSatisfied = pageSatisfied.getOrNull(pagerState.currentPage) == true
        val hasNextPage = pagerState.currentPage < pageCount - 1
        if (currentSatisfied && hasNextPage) {
            kotlinx.coroutines.delay(600)
            if (pageSatisfied.getOrNull(pagerState.currentPage) == true) {
                pagerState.animateScrollToPage(pagerState.currentPage + 1)
            }
        }
    }

    Scaffold(
        containerColor = BgVoid,
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(padding),
        ) {
            PermissionHeader()

            PageDotsIndicator(
                pageCount = pageCount,
                currentPage = pagerState.currentPage,
                pageSatisfied = pageSatisfied,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Spacing.xl, vertical = Spacing.md),
            )

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f),
                // Swipe MAJU dikunci kalau halaman saat ini belum terpenuhi
                // DAN kita di alur wajib (requireAccessToContinue) — dicek
                // per-swipe lewat userScrollEnabled kombinasi arah tidak
                // tersedia langsung di API Pager, jadi penguncian utama
                // sebenarnya ada di tombol "Lanjut" (userScrollEnabled tetap
                // true supaya pengguna masih bisa swipe BEBAS mundur/meninjau
                // ulang halaman manapun yang sudah pernah dilewati).
                userScrollEnabled = true,
            ) { page ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = Spacing.xl)
                        .padding(bottom = Spacing.xxl),
                ) {
                    when (page) {
                        0 -> AccessMethodPage(
                            status = status,
                            context = context,
                        )
                        1 -> WriteSettingsPage(status = status, context = context)
                        2 -> OverlayPage(status = status, context = context)
                        3 -> NotificationsPage(
                            status = status,
                            onRequestNotifications = {
                                notificationLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            },
                        )
                        4 -> KernelWarningPage(
                            acknowledged = kernelWarningAcknowledged,
                            onAcknowledgedChange = { kernelWarningAcknowledged = it },
                        )
                    }
                }
            }

            // --- CTA bawah: sedikit elevasi warna supaya terlihat menempel
            // di dasar layar (sticky look) tanpa benar-benar overlay/shadow. ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCardAlt)
                    .padding(horizontal = Spacing.xxl, vertical = Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.sm),
            ) {
                val isLastPage = pagerState.currentPage == pageCount - 1
                val currentPageSatisfied = pageSatisfied.getOrNull(pagerState.currentPage) == true
                // Tombol halaman ini nonaktif kalau alur WAJIB DAN syarat
                // halaman saat ini belum terpenuhi — pola sama seperti
                // sebelumnya (canContinue), tapi sekarang dievaluasi PER
                // HALAMAN, bukan cuma sekali di akhir.
                val nextEnabled = !requireAccessToContinue || currentPageSatisfied

                Button(
                    onClick = {
                        if (isLastPage) {
                            onContinue()
                        } else {
                            scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                        }
                    },
                    enabled = nextEnabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentBlue,
                        contentColor = OnAccentBlue,
                        disabledContainerColor = StrokeSubtle,
                        disabledContentColor = TextMuted,
                    ),
                ) {
                    Text(
                        text = if (isLastPage) {
                            stringResource(R.string.setup_action_continue)
                        } else {
                            stringResource(R.string.setup_action_next)
                        },
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                AnimatedVisibility(visible = !nextEnabled, enter = fadeIn(), exit = fadeOut()) {
                    Text(
                        text = stringResource(R.string.setup_locked_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

// =============================================================================
// Halaman 1 — Metode akses (ADB tertanam ATAU Root)
// =============================================================================

@Composable
private fun AccessMethodPage(
    status: com.aether.x.core.permission.PrivilegeStatus,
    context: android.content.Context,
) {
    PageIcon(icon = Icons.Outlined.Shield, tint = AccentBlue)
    PageTitle(
        title = stringResource(R.string.setup_page_access_title),
        subtitle = stringResource(R.string.setup_page_access_subtitle),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))

    ReadinessBanner(canContinue = status.hasAccess)
    Spacer(modifier = Modifier.height(Spacing.lg))

    Column(verticalArrangement = Arrangement.spacedBy(Spacing.md)) {
        // ADB Tertanam dan Root TIDAK BOLEH aktif bersamaan (lihat
        // PrivilegeStatus.preferredBackend) — begitu salah satu dipilih
        // pengguna, kartu yang lain terkunci (redup + tombol nonaktif)
        // sampai pengguna menekan "Ganti metode" di bawah.
        val adbLocked = status.preferredBackend == PrivilegeBackend.ROOT
        val rootLocked = status.preferredBackend == PrivilegeBackend.ADB

        AdbPairingCard(
            connected = status.adbGranted && !adbLocked,
            // PairingFound/SearchingForPairing TETAP dianggap "belum
            // paired" di sisi kartu utama — progresnya sepenuhnya
            // ditampilkan lewat notifikasi mengambang + dialog kode,
            // bukan di kartu ini.
            paired = status.adbState.let {
                it != AdbConnectionState.NotPaired &&
                    it !is AdbConnectionState.SearchingForPairing &&
                    it !is AdbConnectionState.PairingFound
            },
            isBusy = status.adbRequestState == RequestState.REQUESTING,
            locked = adbLocked,
            lockedHint = stringResource(R.string.setup_locked_by_root_hint),
            onOpenWirelessDebugging = { PrivilegeManager.openWirelessDebuggingSettings(context) },
            onStartAutoPairing = { PrivilegeManager.startAutoPairAdb(context) },
            onReconnect = { PrivilegeManager.reconnectAdb(context) },
            onForget = { PrivilegeManager.forgetAdbPairing() },
        )

        if (!status.hasAccess) {
            OrDivider()
        }

        PermissionMethodCard(
            title = stringResource(R.string.setup_method_root),
            description = stringResource(R.string.setup_method_root_desc),
            statusText = when {
                status.checkingRoot -> stringResource(R.string.setup_status_checking)
                status.rootGranted -> stringResource(R.string.setup_status_granted)
                else -> stringResource(R.string.setup_status_not_granted)
            },
            granted = status.rootGranted && !rootLocked,
            locked = rootLocked,
            lockedHint = stringResource(R.string.setup_locked_by_adb_hint),
            actionLabel = stringResource(R.string.setup_action_request),
            onAction = { PrivilegeManager.requestRoot(context) },
            isRequesting = status.rootRequestState == RequestState.REQUESTING,
            requestingLabel = stringResource(R.string.setup_action_requesting),
        )

        // Muncul begitu pengguna sudah memilih salah satu metode (kartu
        // lain jadi terkunci) — satu-satunya jalan untuk beralih ke
        // metode lain tanpa perlu mencabut izin manual dari
        // Magisk/Pengaturan sistem.
        AnimatedVisibility(
            visible = status.preferredBackend != PrivilegeBackend.NONE,
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Text(
                    text = stringResource(R.string.setup_switch_method),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = AccentBlue,
                    modifier = Modifier
                        .padding(top = Spacing.xs)
                        .clickable { PrivilegeManager.clearBackendPreference(context) },
                )
            }
        }
    }
}

// =============================================================================
// Halaman 2 — Ubah Pengaturan Sistem (WRITE_SETTINGS)
// =============================================================================

@Composable
private fun WriteSettingsPage(
    status: com.aether.x.core.permission.PrivilegeStatus,
    context: android.content.Context,
) {
    PageIcon(icon = Icons.Outlined.Tune, tint = AccentBlue)
    PageTitle(
        title = stringResource(R.string.setup_page_write_settings_title),
        subtitle = stringResource(R.string.setup_page_write_settings_subtitle),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))
    ReadinessBanner(
        canContinue = status.writeSettingsGranted,
        notReadyText = stringResource(R.string.setup_page_write_settings_banner),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))

    PermissionMethodCard(
        title = stringResource(R.string.setup_method_write_settings),
        description = stringResource(R.string.setup_method_write_settings_desc),
        statusText = if (status.writeSettingsGranted) {
            stringResource(R.string.setup_status_granted)
        } else {
            stringResource(R.string.setup_status_not_granted)
        },
        granted = status.writeSettingsGranted,
        actionLabel = stringResource(R.string.setup_action_request),
        onAction = { PrivilegeManager.requestWriteSettings(context) },
    )
}

// =============================================================================
// Halaman 3 — Tampil di Atas Aplikasi Lain (SYSTEM_ALERT_WINDOW)
// =============================================================================

@Composable
private fun OverlayPage(
    status: com.aether.x.core.permission.PrivilegeStatus,
    context: android.content.Context,
) {
    PageIcon(icon = Icons.Outlined.Layers, tint = AccentBlue)
    PageTitle(
        title = stringResource(R.string.setup_page_overlay_title),
        subtitle = stringResource(R.string.setup_page_overlay_subtitle),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))
    ReadinessBanner(
        canContinue = status.overlayGranted,
        notReadyText = stringResource(R.string.setup_page_overlay_banner),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))

    PermissionMethodCard(
        title = stringResource(R.string.setup_method_overlay),
        description = stringResource(R.string.setup_method_overlay_desc),
        statusText = if (status.overlayGranted) {
            stringResource(R.string.setup_status_granted)
        } else {
            stringResource(R.string.setup_status_not_granted)
        },
        granted = status.overlayGranted,
        actionLabel = stringResource(R.string.setup_action_request),
        onAction = { PrivilegeManager.requestOverlayPermission(context) },
    )
}

// =============================================================================
// Halaman 4 — Notifikasi (POST_NOTIFICATIONS)
// =============================================================================

@Composable
private fun NotificationsPage(
    status: com.aether.x.core.permission.PrivilegeStatus,
    onRequestNotifications: () -> Unit,
) {
    PageIcon(icon = Icons.Outlined.NotificationsActive, tint = AccentBlue)
    PageTitle(
        title = stringResource(R.string.setup_page_notifications_title),
        subtitle = stringResource(R.string.setup_page_notifications_subtitle),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))
    ReadinessBanner(
        canContinue = status.notificationsGranted,
        notReadyText = stringResource(R.string.setup_page_notifications_banner),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))

    PermissionMethodCard(
        title = stringResource(R.string.setup_method_notifications),
        description = stringResource(R.string.setup_method_notifications_desc),
        statusText = if (status.notificationsGranted) {
            stringResource(R.string.setup_status_granted)
        } else {
            stringResource(R.string.setup_status_not_granted)
        },
        granted = status.notificationsGranted,
        actionLabel = stringResource(R.string.setup_action_request),
        onAction = onRequestNotifications,
    )
}

// =============================================================================
// Halaman 5 — Peringatan Kernel (DWYOR) — acknowledgment, BUKAN izin sistem.
// =============================================================================

/**
 * FITUR BARU (lihat perintah rework: "ada peringatan, harus hati' dalam
 * mengatur kernel core CPU/GPU DWYOR"). DWYOR = "Do With Your Own Risk" —
 * peringatan standar komunitas kernel/root Android bahwa mengubah
 * governor CPU/GPU, frekuensi per-core, dan tweak level kernel lain
 * (lihat KernelManagerSection/KernelManagerViewModel) BISA menyebabkan
 * ketidakstabilan sistem (reboot paksa, bootloop pada kasus ekstrem
 * seperti undervolt terlalu agresif) kalau diatur sembarangan tanpa
 * memahami batas aman chipset masing-masing perangkat.
 *
 * SENGAJA bukan permission Android (tidak ada dialog sistem terkait) —
 * murni checkbox acknowledgment pengguna, tapi diperlakukan SETARA
 * dengan 4 halaman izin sebelumnya (wajib dicentang sebelum tombol
 * "Selesai" aktif) supaya peringatan ini benar-benar dibaca, bukan
 * di-skip sekilas seperti dialog EULA yang biasa diabaikan pengguna.
 */
@Composable
private fun KernelWarningPage(
    acknowledged: Boolean,
    onAcknowledgedChange: (Boolean) -> Unit,
) {
    PageIcon(icon = Icons.Outlined.WarningAmber, tint = AccentRed)
    PageTitle(
        title = stringResource(R.string.setup_page_kernel_warning_title),
        subtitle = stringResource(R.string.setup_page_kernel_warning_subtitle),
    )
    Spacer(modifier = Modifier.height(Spacing.lg))

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCardAlt)
            .padding(Spacing.xl),
        verticalArrangement = Arrangement.spacedBy(Spacing.md),
    ) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
            Icon(
                imageVector = Icons.Outlined.Bolt,
                contentDescription = null,
                tint = AccentRed,
                modifier = Modifier.size(20.dp),
            )
            Text(
                text = stringResource(R.string.setup_kernel_warning_point_governor),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        }
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
            Icon(
                imageVector = Icons.Outlined.Bolt,
                contentDescription = null,
                tint = AccentRed,
                modifier = Modifier.size(20.dp),
            )
            Text(
                text = stringResource(R.string.setup_kernel_warning_point_thermal),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        }
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(Spacing.sm)) {
            Icon(
                imageVector = Icons.Outlined.Bolt,
                contentDescription = null,
                tint = AccentRed,
                modifier = Modifier.size(20.dp),
            )
            Text(
                text = stringResource(R.string.setup_kernel_warning_point_responsibility),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        }
    }

    Spacer(modifier = Modifier.height(Spacing.lg))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onAcknowledgedChange(!acknowledged) }
            .padding(vertical = Spacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = acknowledged,
            onCheckedChange = onAcknowledgedChange,
            colors = CheckboxDefaults.colors(checkedColor = AccentBlue),
        )
        Text(
            text = stringResource(R.string.setup_kernel_warning_acknowledge),
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
            modifier = Modifier.padding(start = Spacing.xs),
        )
    }
}

// =============================================================================
// Komponen bersama antar halaman
// =============================================================================

@Composable
private fun PageIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: androidx.compose.ui.graphics.Color) {
    Box(
        modifier = Modifier
            .padding(top = Spacing.md)
            .size(56.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceCardAlt),
        contentAlignment = Alignment.Center,
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = TextPrimary,
        modifier = Modifier.padding(top = Spacing.lg),
    )
    Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary,
        modifier = Modifier.padding(top = Spacing.xs),
    )
}

/** Header tetap (di luar Pager) — logo/judul umum layar, tidak berubah antar halaman. */
@Composable
private fun PermissionHeader() {
    Column(
        modifier = Modifier
            .padding(top = Spacing.md)
            .padding(horizontal = Spacing.xxl),
    ) {
        Text(
            text = stringResource(R.string.setup_title),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
        )
    }
}

/** Titik-titik indikator progres di atas Pager — hijau untuk halaman yang
 * sudah terpenuhi, biru untuk halaman aktif saat ini, abu untuk sisanya. */
@Composable
private fun PageDotsIndicator(
    pageCount: Int,
    currentPage: Int,
    pageSatisfied: List<Boolean>,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(Spacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (index in 0 until pageCount) {
            val satisfied = pageSatisfied.getOrNull(index) == true
            val isCurrent = index == currentPage
            val color = when {
                satisfied -> AccentGreen
                isCurrent -> AccentBlue
                else -> StrokeSubtle
            }
            Icon(
                imageVector = if (isCurrent || satisfied) Icons.Filled.Circle else Icons.Outlined.Circle,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(if (isCurrent) 10.dp else 8.dp),
            )
        }
    }
}

@Composable
private fun ReadinessBanner(canContinue: Boolean, notReadyText: String = stringResource(R.string.setup_required_banner)) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (canContinue) AccentGreenContainer else SurfaceCardAlt)
            .padding(horizontal = Spacing.lg, vertical = Spacing.md),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Spacing.md),
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (canContinue) AccentGreen else AccentRed),
        )
        Text(
            text = if (canContinue) stringResource(R.string.setup_ready_hint) else notReadyText,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = if (canContinue) AccentGreen else TextSecondary,
        )
    }
}

@Composable
private fun OrDivider() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = stringResource(R.string.setup_or_divider),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextMuted,
        )
    }
}
