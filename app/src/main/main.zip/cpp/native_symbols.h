#pragma once

#include <jni.h>

extern "C" {
JNIEXPORT jbyteArray JNICALL nfgp(JNIEnv* env, jobject thiz, jbyteArray rawInput);

JNIEXPORT jfloatArray JNICALL nsmc(JNIEnv* env, jobject thiz);
JNIEXPORT jfloatArray JNICALL nsmg(JNIEnv* env, jobject thiz);
JNIEXPORT void JNICALL nsmr(JNIEnv* env, jobject thiz);

JNIEXPORT jfloatArray JNICALL nrmc(JNIEnv* env, jobject thiz);
}
