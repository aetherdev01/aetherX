package com.aether.x.ui.main

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SpaceDashboard
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aether.x.R
import com.aether.x.ui.about.AboutScreen
import com.aether.x.ui.membership.MembershipScreen
import com.aether.x.ui.settings.SettingsScreen
import com.aether.x.ui.tweak.TweakScreen
import com.aether.x.ui.tweak.TweakViewModel
import com.aether.x.ui.whatsnew.WhatsNewDialog
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import kotlin.math.roundToInt

private enum class MainTab { TWEAK, MEMBERSHIP, ABOUT, SETTINGS }

@Composable
fun MainScreen(
    onManageAccess: () -> Unit,
    onNavigateToGameBooster: () -> Unit,
) {
    var selectedTab by remember { mutableStateOf(MainTab.TWEAK) }

    // Counter event, bukan Boolean, supaya setiap tap Dashboard dianggap
    // sebagai perintah baru—even ketika tab utama memang sudah Dashboard.
    // Ini memungkinkan TweakScreen mereset sub-tab internalnya ke HOME.
    var dashboardRequest by remember { mutableIntStateOf(0) }

    val tweakViewModel: TweakViewModel = viewModel()

    WhatsNewDialog()

    val navItems = remember {
        listOf(MainTab.TWEAK, MainTab.MEMBERSHIP, MainTab.ABOUT, MainTab.SETTINGS)
    }

    // stringResource() harus dipanggil di scope @Composable biasa (bukan di
    // dalam remember{}), jadi label diambil dulu di sini sebagai val — lalu
    // dipakai sebagai KEY remember di bawah supaya list ikut dibangun ulang
    // kalau saja label berubah (mis. ganti bahasa), tapi tidak pada setiap
    // recompose lain yang tidak relevan (mis. navBarOffsetPx saat scroll).
    val dashboardLabel = stringResource(R.string.nav_bottom_dashboard)
    val membershipLabel = stringResource(R.string.nav_membership)
    val aboutLabel = stringResource(R.string.nav_about)
    val settingsLabel = stringResource(R.string.nav_settings)

    // Dibuat sekali lewat remember, bukan literal listOf(...) langsung di
    // parameter bottomBar — sebelumnya list ini (dan tiap AetherNavItem di
    // dalamnya) dibuat ULANG setiap MainScreen recompose (mis. tiap kali
    // navBarOffsetPx berubah saat scroll), padahal isinya selalu sama.
    // Bukan penyebab langsung bug tap/drag di navbar (pointerInput di sana
    // sudah dikunci ke items.size yang stabil), tapi tetap alokasi
    // percuma pada tiap recompose yang sebaiknya dihindari.
    val navBarItems = remember(dashboardLabel, membershipLabel, aboutLabel, settingsLabel) {
        listOf(
            AetherNavItem(Icons.Outlined.SpaceDashboard, dashboardLabel),
            AetherNavItem(Icons.Outlined.WorkspacePremium, membershipLabel),
            AetherNavItem(Icons.Outlined.Info, aboutLabel),
            AetherNavItem(Icons.Outlined.Settings, settingsLabel),
        )
    }

    // HazeState menghubungkan konten (sumber blur, lewat hazeSource di bawah)
    // dengan navbar (penerima blur, lewat hazeEffect di AetherBottomNavBar) —
    // supaya navbar benar-benar menampilkan konten di baliknya secara buram
    // real-time, bukan cuma translusensi statis.
    val hazeState = rememberHazeState()

    // Navbar ala iOS 26: menyembunyikan diri (geser ke bawah) saat konten
    // di-scroll ke bawah, dan muncul lagi saat di-scroll ke atas. Tinggi bar
    // diukur otomatis lewat onSizeChanged, jadi tidak perlu angka hardcode
    // yang bisa basi kalau tampilan navbar berubah lagi nanti.
    var navBarHeightPx by remember { mutableStateOf(0f) }
    var navBarOffsetPx by remember { mutableStateOf(0f) }
    val navBarScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val newOffset = navBarOffsetPx + available.y
                navBarOffsetPx = newOffset.coerceIn(-navBarHeightPx, 0f)
                return Offset.Zero
            }
        }
    }

    Scaffold(
        modifier = Modifier.nestedScroll(navBarScrollConnection),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            AetherBottomNavBar(
                items = navBarItems,
                selectedIndex = navItems.indexOf(selectedTab),
                onSelect = { index ->
                    val tab = navItems[index]
                    selectedTab = tab
                    if (tab == MainTab.TWEAK) {
                        dashboardRequest++
                    }
                },
                hazeState = hazeState,
                modifier = Modifier
                    .onSizeChanged { navBarHeightPx = it.height.toFloat() }
                    .offset { IntOffset(x = 0, y = -navBarOffsetPx.roundToInt()) },
            )
        },
    ) { padding ->
        // Transisi antar tab: fade + scale halus (bukan potong langsung),
        // supaya perpindahan konten terasa mulus mengikuti indikator navbar
        // yang meluncur di bawah.
        AnimatedContent(
            modifier = Modifier
                .fillMaxSize()
                .hazeSource(state = hazeState),
            targetState = selectedTab,
            transitionSpec = {
                // Direction-aware page transition: the incoming screen follows
                // the same direction as the tab selection/drag. The movement
                // is deliberately restrained so it feels like iOS navigation
                // rather than a fast carousel.
                val movingForward = targetState.ordinal > initialState.ordinal
                val enterFrom = if (movingForward) { 0.065f } else { -0.065f }
                val exitTo = if (movingForward) { -0.035f } else { 0.035f }

                (slideInHorizontally(
                    animationSpec = tween(durationMillis = 380),
                    initialOffsetX = { fullWidth -> (fullWidth * enterFrom).roundToInt() },
                ) + fadeIn(tween(300)) + scaleIn(
                    initialScale = 0.985f,
                    animationSpec = tween(360),
                )) togetherWith
                    (slideOutHorizontally(
                        animationSpec = tween(durationMillis = 250),
                        targetOffsetX = { fullWidth -> (fullWidth * exitTo).roundToInt() },
                    ) + fadeOut(tween(190)) + scaleOut(
                        targetScale = 0.992f,
                        animationSpec = tween(220),
                    ))
            },
            label = "mainTabContent",
        ) { tab ->
            when (tab) {
                MainTab.TWEAK -> TweakScreen(
                    modifier = Modifier,
                    contentPadding = padding,
                    viewModel = tweakViewModel,
                    onNavigateToGameBooster = onNavigateToGameBooster,
                    dashboardRequest = dashboardRequest,
                )
                MainTab.MEMBERSHIP -> MembershipScreen(
                    modifier = Modifier,
                    contentPadding = padding,
                )
                MainTab.ABOUT -> AboutScreen(
                    modifier = Modifier,
                    contentPadding = padding,
                )
                MainTab.SETTINGS -> SettingsScreen(
                    modifier = Modifier,
                    contentPadding = padding,
                    onManageAccess = onManageAccess,
                )
            }
        }
    }
}
