package com.aether.x.ui.tweak

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.DeveloperBoard
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.SdStorage
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aether.x.R
import com.aether.x.core.apps.InstalledGameEntry
import com.aether.x.core.permission.PrivilegeManager
import com.aether.x.data.GameMode
import com.aether.x.data.GameProfile
import com.aether.x.ui.components.SectionCard
import com.aether.x.ui.components.StatusPill
import com.aether.x.ui.components.TweakSwitch
import com.aether.x.ui.theme.AccentBlue
import com.aether.x.ui.theme.AccentGreen
import com.aether.x.ui.theme.StrokeSubtle
import com.aether.x.ui.theme.SurfaceCardAlt
import com.aether.x.ui.theme.TextMuted
import com.aether.x.ui.theme.TextPrimary
import com.aether.x.ui.theme.TextSecondary

@Composable
fun GameProfileScreen(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(),
    viewModel: GameProfileViewModel = viewModel(),
) {
    val privilegeStatus by PrivilegeManager.status.collectAsStateWithLifecycle()

    if (!privilegeStatus.rootGranted) {
        GameProfileRootRequiredNotice(modifier = modifier, contentPadding = contentPadding)
        return
    }

    val state by viewModel.state.collectAsStateWithLifecycle()

    Box(modifier = modifier.fillMaxSize().padding(contentPadding)) {
        if (state.selectedPackage == null) {
            GameProfileListPane(
                state = state,
                onSearchQueryChange = viewModel::onSearchQueryChange,
                onSelectGame = viewModel::selectGame,
            )
        } else {
            GameProfileDetailPane(
                state = state,
                viewModel = viewModel,
                onBack = viewModel::clearSelection,
            )
        }
    }
}

@Composable
private fun GameProfileRootRequiredNotice(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(),
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(MaterialTheme.shapes.large)
                .background(SurfaceCardAlt),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Outlined.Lock,
                contentDescription = null,
                tint = AccentBlue,
                modifier = Modifier.size(30.dp),
            )
        }
        Text(
            text = stringResource(R.string.game_profile_root_required_title),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(top = 20.dp),
        )
        Text(
            text = stringResource(R.string.game_profile_root_required_desc),
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

@Composable
private fun GameProfileListPane(
    state: GameProfileUiState,
    onSearchQueryChange: (String) -> Unit,
    onSelectGame: (String) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {

        Text(
            text = stringResource(R.string.game_profile_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp),
        )
        Text(
            text = stringResource(R.string.game_profile_scope_disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            modifier = Modifier.padding(bottom = 16.dp),
        )

        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.game_profile_search_hint)) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            shape = MaterialTheme.shapes.large,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = StrokeSubtle,
            ),
        )

        Box(modifier = Modifier.weight(1f).padding(top = 12.dp)) {
            when {
                state.loadingGames -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = AccentBlue)
                    }
                }
                state.filteredGames.isEmpty() -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = stringResource(R.string.game_profile_empty_list),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted,
                        )
                    }
                }
                else -> {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(state.filteredGames, key = { it.packageName }) { entry ->
                            GameListRow(
                                entry = entry,
                                isActive = entry.packageName == state.activeGameProfilePackage,
                                configuredTweakCount = state.profiles[entry.packageName]?.let { profile ->
                                    countEnabledTweaks(profile)
                                } ?: 0,
                                onClick = { onSelectGame(entry.packageName) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameListRow(
    entry: InstalledGameEntry,
    isActive: Boolean,
    configuredTweakCount: Int,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            bitmap = entry.icon,
            contentDescription = null,
            modifier = Modifier
                .size(44.dp)
                .clip(MaterialTheme.shapes.small),
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 14.dp),
        ) {
            Text(
                text = entry.label,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                maxLines = 1,
            )

            Text(
                text = entry.packageName,
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                maxLines = 1,
            )
            if (isActive) {
                StatusPill(
                    text = stringResource(R.string.game_profile_active_badge),
                    containerColor = AccentGreen.copy(alpha = 0.16f),
                    contentColor = AccentGreen,
                    dotColor = AccentGreen,
                    modifier = Modifier.padding(top = 4.dp),
                )
            } else if (configuredTweakCount > 0) {
                Text(
                    text = stringResource(R.string.game_profile_configured_badge, configuredTweakCount),
                    style = MaterialTheme.typography.bodySmall,
                    color = AccentBlue,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
    }
}

@Composable
private fun GameProfileDetailPane(
    state: GameProfileUiState,
    viewModel: GameProfileViewModel,
    onBack: () -> Unit,
) {
    val selectedEntry = state.installedGames.firstOrNull { it.packageName == state.selectedPackage }
    val profile = state.selectedProfile ?: return
    val activeTweakCount = countEnabledTweaks(profile)
    val totalTweakCount = 6

    val context = LocalContext.current
    val activity = context as? Activity

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = null,
                    tint = TextPrimary,
                )
            }
        }

        if (selectedEntry != null) {
            GameIdentityCard(
                entry = selectedEntry,
                isActive = selectedEntry.packageName == state.activeGameProfilePackage,
                activeTweakCount = activeTweakCount,
                totalTweakCount = totalTweakCount,
            )

            SectionCard(title = stringResource(R.string.game_profile_app_info_title), watermarkIcon = Icons.Outlined.Info) {
                GameInfoRow(
                    label = stringResource(R.string.game_profile_app_info_package),
                    value = selectedEntry.packageName,
                )
            }
        }

        SectionCard(title = stringResource(R.string.game_profile_mode_label), watermarkIcon = Icons.Outlined.SportsEsports) {
            GameModeSelector(
                selected = profile.gameMode,
                onSelect = { mode -> viewModel.onGameModeChange(mode, activity) },
            )
        }

        SectionCard(title = stringResource(R.string.game_profile_category_cpu), watermarkIcon = Icons.Outlined.Memory) {
            TweakSwitch(
                label = stringResource(R.string.tweak_cpu_performance),
                description = stringResource(R.string.tweak_cpu_performance_desc),
                checked = profile.cpuPerformanceMode,
                onCheckedChange = { checked -> viewModel.onCpuPerformanceModeChange(checked, activity) },
                icon = Icons.Outlined.Speed,
            )
            TweakSwitch(
                label = stringResource(R.string.tweak_ram_priority),
                description = stringResource(R.string.tweak_ram_priority_desc),
                checked = profile.ramPriorityMode,
                onCheckedChange = { checked -> viewModel.onRamPriorityModeChange(checked, activity) },
                icon = Icons.Outlined.Memory,
            )
        }

        SectionCard(title = stringResource(R.string.game_profile_category_gpu), watermarkIcon = Icons.Outlined.DeveloperBoard) {
            TweakSwitch(
                label = stringResource(R.string.tweak_gpu_performance),
                description = stringResource(R.string.tweak_gpu_performance_desc),
                checked = profile.gpuPerformanceMode,
                onCheckedChange = { checked -> viewModel.onGpuPerformanceModeChange(checked, activity) },
                icon = Icons.Outlined.DeveloperBoard,
            )
            TweakSwitch(
                label = stringResource(R.string.tweak_thermal_throttle),
                description = stringResource(R.string.tweak_thermal_throttle_desc),
                checked = profile.thermalThrottleOverride,
                onCheckedChange = { checked -> viewModel.onThermalThrottleOverrideChange(checked, activity) },
                icon = Icons.Outlined.Thermostat,
            )

            TweakSwitch(
                label = stringResource(R.string.tweak_gpu_rendering_priority),
                description = stringResource(R.string.tweak_gpu_rendering_priority_desc),
                checked = profile.gpuRenderingPriority,
                onCheckedChange = { checked -> viewModel.onGpuRenderingPriorityChange(checked, activity) },
                icon = Icons.Outlined.Bolt,
            )
        }

        SectionCard(title = stringResource(R.string.game_profile_category_system), watermarkIcon = Icons.Outlined.Build) {
            TweakSwitch(
                label = stringResource(R.string.tweak_io_scheduler_boost),
                description = stringResource(R.string.tweak_io_scheduler_boost_desc),
                checked = profile.ioSchedulerBoost,
                onCheckedChange = { checked -> viewModel.onIoSchedulerBoostChange(checked, activity) },
                icon = Icons.Outlined.SdStorage,
            )
            TweakSwitch(
                label = stringResource(R.string.tweak_vm_heap_boost),
                description = stringResource(R.string.tweak_vm_heap_boost_desc),
                checked = profile.vmHeapBoost,
                onCheckedChange = { checked -> viewModel.onVmHeapBoostChange(checked, activity) },
                icon = Icons.Outlined.Memory,
            )
        }

        OutlinedButton(
            onClick = { viewModel.resetSelectedProfile(activity) },
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, StrokeSubtle),
        ) {
            Text(
                text = stringResource(R.string.game_profile_reset_button),
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

@Composable
private fun GameIdentityCard(
    entry: InstalledGameEntry,
    isActive: Boolean,
    activeTweakCount: Int,
    totalTweakCount: Int,
) {
    SectionCard(title = null, watermarkIcon = Icons.Outlined.Apps) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                bitmap = entry.icon,
                contentDescription = null,
                modifier = Modifier
                    .size(56.dp)
                    .clip(MaterialTheme.shapes.medium),
            )
            Column(modifier = Modifier.padding(start = 14.dp)) {
                Text(
                    text = entry.label,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                )
                Text(
                    text = if (activeTweakCount > 0) {
                        stringResource(R.string.game_profile_summary_active_count, activeTweakCount, totalTweakCount)
                    } else {
                        stringResource(R.string.game_profile_summary_inactive)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (activeTweakCount > 0) AccentBlue else TextMuted,
                    modifier = Modifier.padding(top = 2.dp),
                )
                if (isActive) {
                    StatusPill(
                        text = stringResource(R.string.game_profile_active_badge),
                        containerColor = AccentGreen.copy(alpha = 0.16f),
                        contentColor = AccentGreen,
                        dotColor = AccentGreen,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun GameModeSelector(
    selected: GameMode,
    onSelect: (GameMode) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        GameModeChip(
            label = stringResource(R.string.game_profile_mode_low),
            isSelected = selected == GameMode.LOW,
            onClick = { onSelect(GameMode.LOW) },
            modifier = Modifier.weight(1f),
        )
        GameModeChip(
            label = stringResource(R.string.game_profile_mode_mid),
            isSelected = selected == GameMode.MID,
            onClick = { onSelect(GameMode.MID) },
            modifier = Modifier.weight(1f),
        )
        GameModeChip(
            label = stringResource(R.string.game_profile_mode_boost),
            isSelected = selected == GameMode.BOOST,
            onClick = { onSelect(GameMode.BOOST) },
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun GameModeChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .clip(MaterialTheme.shapes.small)
            .background(if (isSelected) AccentBlue.copy(alpha = 0.18f) else SurfaceCardAlt)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) AccentBlue else StrokeSubtle,
                shape = MaterialTheme.shapes.large,
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (isSelected) AccentBlue else TextSecondary,
        )
    }
}

@Composable
private fun GameInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
        )
    }
}

private fun countEnabledTweaks(profile: GameProfile): Int = listOf(
    profile.cpuPerformanceMode,
    profile.ramPriorityMode,
    profile.thermalThrottleOverride,
    profile.gpuPerformanceMode,
    profile.ioSchedulerBoost,
    profile.vmHeapBoost,
).count { it }
