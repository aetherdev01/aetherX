const { Bot, webhookCallback, InlineKeyboard } = require("grammy");

const { FirestoreClient } = require("./lib/firestoreClient");
const {
  createLicense,
  getLicense,
  updateLicense,
  deleteLicense,
  unbindDevice,
  findLicensesByDevice,
  listAllTokens,
} = require("./lib/licenseStore");
const { getMaintenanceStatus, setMaintenanceStatus } = require("./lib/maintenanceStore");
const { getUpdateInfo, setUpdateInfo } = require("./lib/updateStore");
const { generateUniqueToken } = require("./lib/tokenGenerator");
const {
  formatLicenseCard,
  formatLicenseListSummary,
  formatMaintenanceCard,
  formatUpdateCard,
  isValidToken,
  isValidDeviceId,
  escapeMd,
} = require("./lib/format");

const MAX_GENERATE_COUNT = 50;
const SESSION_TTL_SECONDS = 3600; // sesi percakapan kedaluwarsa 1 jam kalau ditinggal

// ─────────────────────────────────────────────────────────
// SESSION STORAGE (Cloudflare KV)
//
// Beda dari versi Termux (polling, satu proses Node yang hidup terus,
// jadi bisa pakai Map in-memory biasa) — di Cloudflare Workers, tiap
// request webhook bisa "dibangunkan" ulang di instance yang berbeda dan
// variabel global TIDAK dijamin persisten antar-request. Karena itu
// state percakapan (lagi nunggu jawaban apa, dari langkah mana) WAJIB
// disimpan di tempat eksternal — di sini pakai Workers KV.
// ─────────────────────────────────────────────────────────
function sessionKey(chatId) {
  return `session:${chatId}`;
}

async function getSession(env, chatId) {
  const raw = await env.AETHERX_KV.get(sessionKey(chatId));
  return raw ? JSON.parse(raw) : null;
}

async function setSession(env, chatId, session) {
  await env.AETHERX_KV.put(sessionKey(chatId), JSON.stringify(session), {
    expirationTtl: SESSION_TTL_SECONDS,
  });
}

async function clearSession(env, chatId) {
  await env.AETHERX_KV.delete(sessionKey(chatId));
}

function isAdmin(env, userId) {
  return String(userId) === String(env.ADMIN_TELEGRAM_ID || "");
}

async function requireAdmin(bot, env, chatId, userId) {
  if (!isAdmin(env, userId)) {
    await bot.api.sendMessage(chatId, "Kamu tidak punya akses ke perintah ini.");
    return false;
  }
  return true;
}

// ── Helper: kirim pesan "prompt" (yang menunggu balasan user) dan simpan
// message_id-nya di session, supaya nanti bisa DI-EDIT jadi hasil akhirnya
// begitu user membalas — tanpa mengirim pesan baru terpisah. ──
async function sendPrompt(bot, env, chatId, text, options = {}) {
  const sent = await bot.api.sendMessage(chatId, text, options);
  const session = await getSession(env, chatId);
  if (session) {
    session.promptMessageId = sent.message_id;
    await setSession(env, chatId, session);
  }
  return sent;
}

// ── Helper: setelah user membalas prompt, tampilkan hasil akhir dengan cara
// MENGEDIT pesan prompt tadi (bukan mengirim pesan baru). Kalau edit gagal
// (mis. pesan sudah kedaluwarsa/dihapus/isinya identik), fallback kirim
// pesan baru supaya hasil tetap sampai ke user. Selalu mengembalikan objek
// dengan `message_id` yang valid (Telegram API kadang membalas edit dengan
// `true` alih-alih objek Message, jadi kita normalisasi di sini).
async function resolvePrompt(bot, chatId, promptMessageId, text, options = {}) {
  if (promptMessageId) {
    try {
      const result = await bot.api.editMessageText(chatId, promptMessageId, text, {
        parse_mode: options.parse_mode,
        reply_markup: options.reply_markup,
        disable_web_page_preview: options.disable_web_page_preview,
      });
      return typeof result === "object" ? result : { message_id: promptMessageId };
    } catch (err) {
      // Edit gagal (mis. "message is not modified" atau pesan sudah tidak ada) — fallback kirim baru.
    }
  }
  return bot.api.sendMessage(chatId, text, options);
}

function mainMenuKeyboard() {
  return new InlineKeyboard()
    .text("Generate Lisensi", "menu:generate")
    .text("Cek Lisensi", "menu:check")
    .row()
    .text("Edit Lisensi", "menu:edit")
    .text("Hapus Lisensi", "menu:delete")
    .row()
    .text("Cek Device ID", "menu:device")
    .text("Reset Device", "menu:unbind")
    .row()
    .text("Daftar Lisensi", "menu:list")
    .row()
    .text("Maintenance", "menu:maintenance")
    .text("Update Versi", "menu:update");
}

function maintenanceMenuKeyboard(status) {
  const kb = new InlineKeyboard();
  if (status.enabled) {
    kb.text("Matikan Maintenance", "maint:disable");
  } else {
    kb.text("Aktifkan Maintenance", "maint:enable");
  }
  kb.row().text("Edit Judul", "maint:edit_title").text("Edit Pesan", "maint:edit_message");
  kb.row().text("❌ Tutup", "maint:close");
  return kb;
}

function updateMenuKeyboard(info) {
  const kb = new InlineKeyboard().text("Publish Versi Baru", "upd:publish").row();
  kb.text("Edit Link Download", "upd:edit_url").text("Edit Deskripsi", "upd:edit_desc").row();
  if (info.mandatory) {
    kb.text("Jadikan Opsional", "upd:optional");
  } else {
    kb.text("Jadikan Wajib", "upd:mandatory");
  }
  kb.row().text("❌ Tutup", "upd:close");
  return kb;
}

// ─────────────────────────────────────────────────────────
// Bangun instance bot grammY dan daftarkan semua handler.
// Dipanggil sekali per request oleh fetch handler di bawah, memakai
// firestore client dan env (secrets/KV) yang relevan dengan request itu.
// ─────────────────────────────────────────────────────────
function createBot(env) {
  const bot = new Bot(env.TELEGRAM_BOT_TOKEN);

  let serviceAccount;
  try {
    serviceAccount = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT);
  } catch (err) {
    throw new Error(
      "Secret FIREBASE_SERVICE_ACCOUNT tidak valid atau bukan JSON. Isi dengan seluruh isi file serviceAccountKey.json."
    );
  }
  const firestore = new FirestoreClient(serviceAccount);

  if (env.EXPECTED_PROJECT_ID && firestore.projectId !== env.EXPECTED_PROJECT_ID) {
    throw new Error(
      `FIREBASE_SERVICE_ACCOUNT ini untuk project Firebase "${firestore.projectId}", ` +
        `tapi EXPECTED_PROJECT_ID diisi "${env.EXPECTED_PROJECT_ID}". Lisensi yang dibuat bot ini ` +
        `TIDAK akan terlihat di aplikasi Android kalau project-nya beda.`
    );
  }

  // ── /start & /help ──
  bot.command("start", async (ctx) => {
    await clearSession(env, ctx.chat.id);
    const name = escapeMd(ctx.from.first_name || "");
    await ctx.reply(
      `Halo, ${name}\\!\n\n` +
        `Bot manajemen lisensi *AetherX* siap dipakai \\(terhubung ke Firestore\\)\\.\n` +
        `Pilih menu di bawah, atau ketik /help untuk daftar perintah lengkap\\.`,
      { parse_mode: "MarkdownV2", reply_markup: mainMenuKeyboard() }
    );
  });

  bot.command("help", async (ctx) => {
    const helpText = [
      "Perintah tersedia:",
      "",
      "/generate <jumlah> <hari> [catatan] — Buat lisensi baru. Contoh: /generate 5 30 Promo Juli",
      "/check <token> — Lihat detail lisensi",
      "/edit <token> — Edit status/expiry/device/catatan lisensi",
      "/delete <token> — Hapus lisensi permanen",
      "/device <deviceId> — Cari lisensi yang terpasang di device ID tsb",
      "/unbind <token> — Lepas device dari lisensi (reset ke status 'unused')",
      "/list — Daftar semua token lisensi",
      "/maintenance — Lihat/atur mode maintenance (dialog blocking di app)",
      "/update — Lihat/publish info versi terbaru (dialog update opsional di app)",
      "/cancel — Batalkan proses yang sedang berjalan",
      "",
      "Semua perintah admin hanya bisa dipakai oleh admin yang terdaftar.",
    ].join("\n");
    await ctx.reply(helpText);
  });

  bot.command("cancel", async (ctx) => {
    await clearSession(env, ctx.chat.id);
    await ctx.reply("Proses dibatalkan.", { reply_markup: mainMenuKeyboard() });
  });

  // ─────────────────────────────────────────────────────────
  // GENERATE LICENSE
  // /generate <jumlah> <hari> [catatan]
  // ─────────────────────────────────────────────────────────
  async function doGenerate(chatId, count, days, note, promptMessageId) {
    try {
      if (count === 1) {
        const token = await generateUniqueToken(firestore);
        const license = await createLicense(firestore, { token, days, note });
        await resolvePrompt(
          bot,
          chatId,
          promptMessageId,
          `*Lisensi baru berhasil dibuat\\!*\n\n${formatLicenseCard(license)}`,
          { parse_mode: "MarkdownV2" }
        );
        return;
      }

      // Generate berurutan (bukan paralel) supaya setiap panggilan generateUniqueToken
      // mengecek tabrakan terhadap token-token yang baru saja dibuat di batch ini juga.
      const licenses = [];
      for (let i = 0; i < count; i++) {
        const token = await generateUniqueToken(firestore);
        const license = await createLicense(firestore, { token, days, note });
        licenses.push(license);
      }

      await resolvePrompt(
        bot,
        chatId,
        promptMessageId,
        `*${count} lisensi baru berhasil dibuat\\!*\n\n${formatLicenseListSummary(licenses)}`,
        { parse_mode: "MarkdownV2" }
      );
    } catch (err) {
      console.error(err);
      await bot.api.sendMessage(chatId, `❌ Gagal generate lisensi: ${err.message}`);
    }
  }

  bot.command("generate", async (ctx) => {
    if (!(await requireAdmin(bot, env, ctx.chat.id, ctx.from.id))) return;
    const chatId = ctx.chat.id;
    const raw = (ctx.match || "").trim();

    if (!raw) {
      await setSession(env, chatId, { action: "generate", step: "ask_count" });
      await sendPrompt(bot, env, chatId, `Mau generate berapa lisensi? (1-${MAX_GENERATE_COUNT}, mis. \`1\`)`, {
        parse_mode: "Markdown",
      });
      return;
    }

    const parts = raw.split(/\s+/);
    const count = parseInt(parts[0], 10);
    const days = parseInt(parts[1], 10);
    const note = parts.slice(2).join(" ");

    if (!Number.isFinite(count) || count <= 0 || count > MAX_GENERATE_COUNT) {
      await ctx.reply(
        `Jumlah lisensi harus angka 1-${MAX_GENERATE_COUNT}. Format: /generate <jumlah> <hari> [catatan]. Contoh: /generate 5 30 Promo Juli`
      );
      return;
    }
    if (!Number.isFinite(days) || days <= 0) {
      await ctx.reply("Format: /generate <jumlah> <hari> [catatan]. Contoh: /generate 5 30 Promo Juli");
      return;
    }

    await doGenerate(chatId, count, days, note);
  });

  // ─────────────────────────────────────────────────────────
  // CHECK LICENSE
  // ─────────────────────────────────────────────────────────
  async function handleCheck(chatId, token, promptMessageId) {
    if (!isValidToken(token)) {
      await bot.api.sendMessage(chatId, "Format token tidak valid. Token harus 12 karakter huruf/angka.");
      return;
    }
    try {
      const license = await getLicense(firestore, token);
      if (!license) {
        await resolvePrompt(bot, chatId, promptMessageId, `❌ Token \`${token}\` tidak ditemukan.`, {
          parse_mode: "Markdown",
        });
        return;
      }
      await resolvePrompt(bot, chatId, promptMessageId, formatLicenseCard(license), { parse_mode: "MarkdownV2" });
    } catch (err) {
      console.error(err);
      await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
    }
  }

  bot.command("check", async (ctx) => {
    const chatId = ctx.chat.id;
    const token = (ctx.match || "").trim();
    if (!token) {
      await setSession(env, chatId, { action: "check", step: "waiting_token" });
      await sendPrompt(bot, env, chatId, "Kirim token lisensi yang mau dicek (12 karakter):");
      return;
    }
    await handleCheck(chatId, token);
  });

  // ─────────────────────────────────────────────────────────
  // DEVICE ID LOOKUP
  // ─────────────────────────────────────────────────────────
  async function handleDeviceCheck(chatId, deviceId, promptMessageId) {
    if (!isValidDeviceId(deviceId)) {
      await bot.api.sendMessage(chatId, "Device ID tidak valid (minimal 4 karakter).");
      return;
    }
    try {
      const licenses = await findLicensesByDevice(firestore, deviceId);
      if (licenses.length === 0) {
        await resolvePrompt(
          bot,
          chatId,
          promptMessageId,
          `Device ID \`${deviceId}\` belum terdaftar di lisensi manapun.`,
          { parse_mode: "Markdown" }
        );
        return;
      }
      const cards = licenses.map(formatLicenseCard).join("\n\n───\n\n");
      await resolvePrompt(bot, chatId, promptMessageId, `Lisensi yang terkait Device ID ini:\n\n${cards}`, {
        parse_mode: "MarkdownV2",
      });
    } catch (err) {
      console.error(err);
      await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
    }
  }

  bot.command("device", async (ctx) => {
    const chatId = ctx.chat.id;
    const deviceId = (ctx.match || "").trim();
    if (!deviceId) {
      await setSession(env, chatId, { action: "device", step: "waiting_device" });
      await sendPrompt(bot, env, chatId, "Kirim Device ID yang mau dicek:");
      return;
    }
    await handleDeviceCheck(chatId, deviceId);
  });

  // ─────────────────────────────────────────────────────────
  // UNBIND DEVICE
  // ─────────────────────────────────────────────────────────
  async function handleUnbind(chatId, token, promptMessageId) {
    if (!isValidToken(token)) {
      await bot.api.sendMessage(chatId, "Format token tidak valid.");
      return;
    }
    try {
      const license = await getLicense(firestore, token);
      if (!license) {
        await resolvePrompt(bot, chatId, promptMessageId, `❌ Token \`${token}\` tidak ditemukan.`, {
          parse_mode: "Markdown",
        });
        return;
      }
      await unbindDevice(firestore, token);
      await resolvePrompt(
        bot,
        chatId,
        promptMessageId,
        `Device berhasil dilepas dari token \`${token}\`. Status dikembalikan ke 'unused', lisensi bisa dipakai di device baru.`,
        { parse_mode: "Markdown" }
      );
    } catch (err) {
      console.error(err);
      await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
    }
  }

  bot.command("unbind", async (ctx) => {
    if (!(await requireAdmin(bot, env, ctx.chat.id, ctx.from.id))) return;
    const chatId = ctx.chat.id;
    const token = (ctx.match || "").trim();
    if (!token) {
      await setSession(env, chatId, { action: "unbind", step: "waiting_token" });
      await sendPrompt(bot, env, chatId, "Kirim token lisensi yang device-nya mau direset:");
      return;
    }
    await handleUnbind(chatId, token);
  });

  // ─────────────────────────────────────────────────────────
  // DELETE LICENSE
  // ─────────────────────────────────────────────────────────
  async function confirmDelete(chatId, token, promptMessageId) {
    if (!isValidToken(token)) {
      await bot.api.sendMessage(chatId, "Format token tidak valid.");
      return;
    }
    const license = await getLicense(firestore, token);
    if (!license) {
      await resolvePrompt(bot, chatId, promptMessageId, `❌ Token \`${token}\` tidak ditemukan.`, {
        parse_mode: "Markdown",
      });
      return;
    }
    const confirmKeyboard = new InlineKeyboard()
      .text("Ya, hapus", `delete_confirm:${token}`)
      .text("❌ Batal", "delete_cancel");
    await resolvePrompt(
      bot,
      chatId,
      promptMessageId,
      `Yakin mau hapus lisensi ini secara permanen?\n\n${formatLicenseCard(license)}`,
      { parse_mode: "MarkdownV2", reply_markup: confirmKeyboard }
    );
    await setSession(env, chatId, { action: "delete", step: "confirm", data: { token } });
  }

  bot.command("delete", async (ctx) => {
    if (!(await requireAdmin(bot, env, ctx.chat.id, ctx.from.id))) return;
    const chatId = ctx.chat.id;
    const token = (ctx.match || "").trim();
    if (!token) {
      await setSession(env, chatId, { action: "delete", step: "waiting_token" });
      await sendPrompt(bot, env, chatId, "Kirim token lisensi yang mau dihapus:");
      return;
    }
    await confirmDelete(chatId, token);
  });

  // ─────────────────────────────────────────────────────────
  // LIST
  // ─────────────────────────────────────────────────────────
  bot.command("list", async (ctx) => {
    if (!(await requireAdmin(bot, env, ctx.chat.id, ctx.from.id))) return;
    const chatId = ctx.chat.id;
    try {
      const tokens = await listAllTokens(firestore);
      if (tokens.length === 0) {
        await ctx.reply("Belum ada lisensi yang dibuat.");
        return;
      }
      const preview = tokens.slice(0, 50);
      const text =
        `*Total ${tokens.length} lisensi*${tokens.length > 50 ? " (menampilkan 50 pertama)" : ""}:\n\n` +
        preview.map((t) => `\`${t}\``).join("\n");
      await ctx.reply(text, { parse_mode: "Markdown" });
    } catch (err) {
      console.error(err);
      await ctx.reply(`❌ Terjadi error: ${err.message}`);
    }
  });

  // ─────────────────────────────────────────────────────────
  // MAINTENANCE MODE
  // ─────────────────────────────────────────────────────────
  async function showMaintenanceMenu(chatId, editMessageId) {
    try {
      const status = await getMaintenanceStatus(firestore);
      if (editMessageId) {
        await resolvePrompt(bot, chatId, editMessageId, formatMaintenanceCard(status), {
          parse_mode: "MarkdownV2",
          reply_markup: maintenanceMenuKeyboard(status),
        });
        return;
      }
      await bot.api.sendMessage(chatId, formatMaintenanceCard(status), {
        parse_mode: "MarkdownV2",
        reply_markup: maintenanceMenuKeyboard(status),
      });
    } catch (err) {
      console.error(err);
      await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
    }
  }

  bot.command("maintenance", async (ctx) => {
    if (!(await requireAdmin(bot, env, ctx.chat.id, ctx.from.id))) return;
    await showMaintenanceMenu(ctx.chat.id);
  });

  // ─────────────────────────────────────────────────────────
  // UPDATE VERSI APLIKASI
  // ─────────────────────────────────────────────────────────
  async function showUpdateMenu(chatId, editMessageId) {
    try {
      const info = await getUpdateInfo(firestore);
      if (editMessageId) {
        await resolvePrompt(bot, chatId, editMessageId, formatUpdateCard(info), {
          parse_mode: "MarkdownV2",
          reply_markup: updateMenuKeyboard(info),
        });
        return;
      }
      await bot.api.sendMessage(chatId, formatUpdateCard(info), {
        parse_mode: "MarkdownV2",
        reply_markup: updateMenuKeyboard(info),
      });
    } catch (err) {
      console.error(err);
      await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
    }
  }

  bot.command("update", async (ctx) => {
    if (!(await requireAdmin(bot, env, ctx.chat.id, ctx.from.id))) return;
    await showUpdateMenu(ctx.chat.id);
  });

  // ─────────────────────────────────────────────────────────
  // EDIT LICENSE (conversation flow)
  // ─────────────────────────────────────────────────────────
  async function startEditFlow(chatId, token, promptMessageId) {
    if (!isValidToken(token)) {
      await bot.api.sendMessage(chatId, "Format token tidak valid.");
      return;
    }
    const license = await getLicense(firestore, token);
    if (!license) {
      await resolvePrompt(bot, chatId, promptMessageId, `❌ Token \`${token}\` tidak ditemukan.`, {
        parse_mode: "Markdown",
      });
      return;
    }
    const kb = new InlineKeyboard()
      .text("Status", "edit_field:status")
      .text("Expiry (hari)", "edit_field:expiresAt")
      .row()
      .text("Device ID", "edit_field:deviceId")
      .text("Catatan", "edit_field:note")
      .row()
      .text("❌ Batal", "edit_cancel");
    const sent = await resolvePrompt(bot, chatId, promptMessageId, `Edit lisensi \`${token}\`. Pilih field yang mau diubah:`, {
      parse_mode: "Markdown",
      reply_markup: kb,
    });
    await setSession(env, chatId, {
      action: "edit",
      step: "choose_field",
      data: { token },
      promptMessageId: sent.message_id,
    });
  }

  bot.command("edit", async (ctx) => {
    if (!(await requireAdmin(bot, env, ctx.chat.id, ctx.from.id))) return;
    const chatId = ctx.chat.id;
    const token = (ctx.match || "").trim();
    if (!token) {
      await setSession(env, chatId, { action: "edit", step: "waiting_token" });
      await sendPrompt(bot, env, chatId, "Kirim token lisensi yang mau diedit:");
      return;
    }
    await startEditFlow(chatId, token);
  });

  // ─────────────────────────────────────────────────────────
  // CALLBACK QUERY HANDLER
  // ─────────────────────────────────────────────────────────
  bot.on("callback_query:data", async (ctx) => {
    const chatId = ctx.chat.id;
    const data = ctx.callbackQuery.data;
    const userId = ctx.from.id;
    const messageId = ctx.callbackQuery.message?.message_id;

    ctx.answerCallbackQuery().catch(() => {});

    if (data.startsWith("menu:")) {
      const key = data.split(":")[1];
      if (key === "generate") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        await setSession(env, chatId, { action: "generate", step: "ask_count", promptMessageId: messageId });
        await resolvePrompt(bot, chatId, messageId, `Mau generate berapa lisensi? (1-${MAX_GENERATE_COUNT}, mis. \`1\`)`, {
          parse_mode: "Markdown",
        });
        return;
      }
      if (key === "check") {
        await setSession(env, chatId, { action: "check", step: "waiting_token", promptMessageId: messageId });
        await resolvePrompt(bot, chatId, messageId, "Kirim token lisensi yang mau dicek (12 karakter):");
        return;
      }
      if (key === "edit") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        await setSession(env, chatId, { action: "edit", step: "waiting_token", promptMessageId: messageId });
        await resolvePrompt(bot, chatId, messageId, "Kirim token lisensi yang mau diedit:");
        return;
      }
      if (key === "delete") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        await setSession(env, chatId, { action: "delete", step: "waiting_token", promptMessageId: messageId });
        await resolvePrompt(bot, chatId, messageId, "Kirim token lisensi yang mau dihapus:");
        return;
      }
      if (key === "device") {
        await setSession(env, chatId, { action: "device", step: "waiting_device", promptMessageId: messageId });
        await resolvePrompt(bot, chatId, messageId, "Kirim Device ID yang mau dicek:");
        return;
      }
      if (key === "unbind") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        await setSession(env, chatId, { action: "unbind", step: "waiting_token", promptMessageId: messageId });
        await resolvePrompt(bot, chatId, messageId, "Kirim token lisensi yang device-nya mau direset:");
        return;
      }
      if (key === "list") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        const tokens = await listAllTokens(firestore);
        if (tokens.length === 0) {
          await resolvePrompt(bot, chatId, messageId, "Belum ada lisensi yang dibuat.");
          return;
        }
        const preview = tokens.slice(0, 50);
        await resolvePrompt(
          bot,
          chatId,
          messageId,
          `*Total ${tokens.length} lisensi*:\n\n` + preview.map((t) => `\`${t}\``).join("\n"),
          { parse_mode: "Markdown" }
        );
        return;
      }
      if (key === "maintenance") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        await showMaintenanceMenu(chatId, messageId);
        return;
      }
      if (key === "update") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        await showUpdateMenu(chatId, messageId);
        return;
      }
      return;
    }

    if (data.startsWith("delete_confirm:")) {
      if (!(await requireAdmin(bot, env, chatId, userId))) return;
      const token = data.split(":")[1];
      try {
        const ok = await deleteLicense(firestore, token);
        await clearSession(env, chatId);
        await resolvePrompt(
          bot,
          chatId,
          messageId,
          ok ? `Token \`${token}\` berhasil dihapus.` : `❌ Gagal menghapus token \`${token}\`.`,
          { parse_mode: "Markdown" }
        );
      } catch (err) {
        console.error(err);
        await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
      }
      return;
    }
    if (data === "delete_cancel") {
      await clearSession(env, chatId);
      await resolvePrompt(bot, chatId, messageId, "Penghapusan dibatalkan.");
      return;
    }

    if (data.startsWith("edit_field:")) {
      if (!(await requireAdmin(bot, env, chatId, userId))) return;
      const field = data.split(":")[1];
      const session = await getSession(env, chatId);
      if (!session || session.action !== "edit") {
        await bot.api.sendMessage(chatId, "Sesi edit tidak ditemukan, mulai lagi dengan /edit <token>");
        return;
      }
      session.step = "awaiting_value";
      session.data.field = field;
      session.promptMessageId = messageId;
      await setSession(env, chatId, session);

      const prompts = {
        status: "Kirim status baru: `unused`, `active`, atau `revoked`",
        expiresAt: "Kirim jumlah hari masa berlaku baru dihitung dari SEKARANG (angka):",
        deviceId: "Kirim Device ID baru untuk dikunci ke lisensi ini, atau `-` untuk mengosongkan (reset ke unused):",
        note: "Kirim catatan baru:",
      };
      await resolvePrompt(bot, chatId, messageId, prompts[field] || "Kirim nilai baru:", {
        parse_mode: "Markdown",
      });
      return;
    }
    if (data === "edit_cancel") {
      await clearSession(env, chatId);
      await resolvePrompt(bot, chatId, messageId, "Proses edit dibatalkan.");
      return;
    }

    if (data === "maint:enable" || data === "maint:disable") {
      if (!(await requireAdmin(bot, env, chatId, userId))) return;
      try {
        const status = await setMaintenanceStatus(firestore, { enabled: data === "maint:enable" });
        const notice = status.enabled
          ? "*Mode maintenance DIAKTIFKAN\\.* Seluruh aplikasi Android yang sedang terbuka akan langsung menampilkan dialog blocking dalam beberapa detik\\.\n\n"
          : "*Mode maintenance DIMATIKAN\\.* Dialog blocking di aplikasi akan hilang otomatis\\.\n\n";
        await resolvePrompt(bot, chatId, messageId, notice + formatMaintenanceCard(status), {
          parse_mode: "MarkdownV2",
          reply_markup: maintenanceMenuKeyboard(status),
        });
      } catch (err) {
        console.error(err);
        await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
      }
      return;
    }

    if (data === "maint:edit_title" || data === "maint:edit_message") {
      if (!(await requireAdmin(bot, env, chatId, userId))) return;
      const field = data === "maint:edit_title" ? "title" : "message";
      await setSession(env, chatId, {
        action: "maintenance",
        step: "awaiting_value",
        data: { field },
        promptMessageId: messageId,
      });
      await resolvePrompt(
        bot,
        chatId,
        messageId,
        field === "title" ? "Kirim judul dialog maintenance yang baru:" : "Kirim pesan/deskripsi dialog maintenance yang baru:"
      );
      return;
    }

    if (data === "maint:close") {
      await clearSession(env, chatId);
      await bot.api.deleteMessage(chatId, messageId).catch(() => {});
      return;
    }

    if (data === "upd:publish") {
      if (!(await requireAdmin(bot, env, chatId, userId))) return;
      await setSession(env, chatId, {
        action: "update_publish",
        step: "ask_version_code",
        data: {},
        promptMessageId: messageId,
      });
      await resolvePrompt(
        bot,
        chatId,
        messageId,
        "Kirim *versionCode* rilis baru (angka bulat, harus lebih besar dari versionCode yang sudah terdaftar):",
        { parse_mode: "Markdown" }
      );
      return;
    }

    if (data === "upd:edit_url" || data === "upd:edit_desc") {
      if (!(await requireAdmin(bot, env, chatId, userId))) return;
      const field = data === "upd:edit_url" ? "downloadUrl" : "description";
      await setSession(env, chatId, {
        action: "update_field",
        step: "awaiting_value",
        data: { field },
        promptMessageId: messageId,
      });
      await resolvePrompt(
        bot,
        chatId,
        messageId,
        field === "downloadUrl" ? "Kirim link download rilis (URL GitHub Release):" : "Kirim deskripsi/changelog baru:"
      );
      return;
    }

    if (data === "upd:mandatory" || data === "upd:optional") {
      if (!(await requireAdmin(bot, env, chatId, userId))) return;
      try {
        const info = await setUpdateInfo(firestore, { mandatory: data === "upd:mandatory" });
        const notice = info.mandatory
          ? "*Update dijadikan WAJIB\\.* \\(catatan: saat ini app Android masih menampilkan dialog opsional — field ini disiapkan untuk versi mendatang\\.\\)\n\n"
          : "*Update dijadikan opsional kembali\\.*\n\n";
        await resolvePrompt(bot, chatId, messageId, notice + formatUpdateCard(info), {
          parse_mode: "MarkdownV2",
          reply_markup: updateMenuKeyboard(info),
        });
      } catch (err) {
        console.error(err);
        await bot.api.sendMessage(chatId, `❌ Terjadi error: ${err.message}`);
      }
      return;
    }

    if (data === "upd:close") {
      await clearSession(env, chatId);
      await bot.api.deleteMessage(chatId, messageId).catch(() => {});
      return;
    }
  });

  // ─────────────────────────────────────────────────────────
  // MESSAGE HANDLER — melanjutkan conversation flow
  // ─────────────────────────────────────────────────────────
  bot.on("message:text", async (ctx) => {
    if (ctx.message.text.startsWith("/")) return;
    const chatId = ctx.chat.id;
    const userId = ctx.from.id;
    const session = await getSession(env, chatId);
    if (!session) return;

    const text = ctx.message.text.trim();

    try {
      if (session.action === "check" && session.step === "waiting_token") {
        const promptMessageId = session.promptMessageId;
        await clearSession(env, chatId);
        await handleCheck(chatId, text, promptMessageId);
        return;
      }

      if (session.action === "device" && session.step === "waiting_device") {
        const promptMessageId = session.promptMessageId;
        await clearSession(env, chatId);
        await handleDeviceCheck(chatId, text, promptMessageId);
        return;
      }

      if (session.action === "unbind" && session.step === "waiting_token") {
        const promptMessageId = session.promptMessageId;
        await clearSession(env, chatId);
        await handleUnbind(chatId, text, promptMessageId);
        return;
      }

      if (session.action === "delete" && session.step === "waiting_token") {
        await confirmDelete(chatId, text, session.promptMessageId);
        return;
      }

      if (session.action === "edit" && session.step === "waiting_token") {
        await startEditFlow(chatId, text, session.promptMessageId);
        return;
      }

      if (session.action === "edit" && session.step === "awaiting_value") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        const { token, field } = session.data;
        const promptMessageId = session.promptMessageId;
        const updates = {};

        if (field === "status") {
          if (!["unused", "active", "revoked"].includes(text)) {
            await ctx.reply("Status harus salah satu dari: unused, active, revoked");
            return;
          }
          updates.status = text;
        } else if (field === "expiresAt") {
          const days = parseInt(text, 10);
          if (!Number.isFinite(days) || days <= 0) {
            await ctx.reply("Masukkan angka hari yang valid, lebih dari 0.");
            return;
          }
          updates.expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
        } else if (field === "deviceId") {
          if (text === "-") {
            await unbindDevice(firestore, token);
            await clearSession(env, chatId);
            const updated = await getLicense(firestore, token);
            await resolvePrompt(bot, chatId, promptMessageId, `Device dilepas\\!\n\n${formatLicenseCard(updated)}`, {
              parse_mode: "MarkdownV2",
            });
            return;
          }
          if (!isValidDeviceId(text)) {
            await ctx.reply("Device ID tidak valid (minimal 4 karakter).");
            return;
          }
          updates.deviceId = text;
          updates.status = "active";
          updates.activatedAt = new Date();
        } else if (field === "note") {
          updates.note = text;
        }

        if (Object.keys(updates).length > 0) {
          await updateLicense(firestore, token, updates);
        }

        await clearSession(env, chatId);
        const updated = await getLicense(firestore, token);
        await resolvePrompt(bot, chatId, promptMessageId, `Lisensi berhasil diupdate\\!\n\n${formatLicenseCard(updated)}`, {
          parse_mode: "MarkdownV2",
        });
        return;
      }

      if (session.action === "maintenance" && session.step === "awaiting_value") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        const { field } = session.data;
        const promptMessageId = session.promptMessageId;
        await clearSession(env, chatId);
        try {
          const status = await setMaintenanceStatus(firestore, { [field]: text });
          const notice = `${field === "title" ? "Judul" : "Pesan"} maintenance berhasil diupdate\\!\n\n`;
          await resolvePrompt(bot, chatId, promptMessageId, notice + formatMaintenanceCard(status), {
            parse_mode: "MarkdownV2",
            reply_markup: maintenanceMenuKeyboard(status),
          });
        } catch (err) {
          console.error(err);
          await ctx.reply(`❌ Terjadi error: ${err.message}`);
        }
        return;
      }

      if (session.action === "update_field" && session.step === "awaiting_value") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        const { field } = session.data;
        const promptMessageId = session.promptMessageId;
        await clearSession(env, chatId);
        try {
          const info = await setUpdateInfo(firestore, { [field]: text });
          const notice = `${field === "downloadUrl" ? "Link download" : "Deskripsi"} berhasil diupdate\\!\n\n`;
          await resolvePrompt(bot, chatId, promptMessageId, notice + formatUpdateCard(info), {
            parse_mode: "MarkdownV2",
            reply_markup: updateMenuKeyboard(info),
          });
        } catch (err) {
          console.error(err);
          await ctx.reply(`❌ Terjadi error: ${err.message}`);
        }
        return;
      }

      if (session.action === "update_publish" && session.step === "ask_version_code") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        const versionCode = parseInt(text, 10);
        if (!Number.isFinite(versionCode) || versionCode <= 0) {
          await ctx.reply("Masukkan versionCode berupa angka bulat positif.");
          return;
        }
        const current = await getUpdateInfo(firestore);
        if (versionCode <= current.latestVersionCode) {
          await ctx.reply(
            `versionCode harus lebih besar dari yang sudah terdaftar saat ini (${current.latestVersionCode}). Kirim ulang versionCode yang valid, atau /cancel untuk batal.`
          );
          return;
        }
        session.data.latestVersionCode = versionCode;
        session.step = "ask_version_name";
        await setSession(env, chatId, session);
        const nextPrompt = await resolvePrompt(
          bot,
          chatId,
          session.promptMessageId,
          "Kirim *versionName* rilis ini (mis. `1.2.0` atau `1.2 Beta`):",
          { parse_mode: "Markdown" }
        );
        session.promptMessageId = nextPrompt.message_id;
        await setSession(env, chatId, session);
        return;
      }
      if (session.action === "update_publish" && session.step === "ask_version_name") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        session.data.latestVersionName = text;
        session.step = "ask_download_url";
        await setSession(env, chatId, session);
        const nextPrompt = await resolvePrompt(
          bot,
          chatId,
          session.promptMessageId,
          "Kirim link download (URL GitHub Release) untuk rilis ini:"
        );
        session.promptMessageId = nextPrompt.message_id;
        await setSession(env, chatId, session);
        return;
      }
      if (session.action === "update_publish" && session.step === "ask_download_url") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        session.data.downloadUrl = text;
        session.step = "ask_description";
        await setSession(env, chatId, session);
        const nextPrompt = await resolvePrompt(
          bot,
          chatId,
          session.promptMessageId,
          [
            "Kirim deskripsi/changelog rilis ini (boleh multi-baris), atau `-` untuk kosongkan.",
            "",
            "Format yang didukung di app:",
            "• `**tebal**` dan `*miring*`",
            "• `- item` di awal baris jadi bullet point",
            "• `[blue]teks[/blue]` teks berwarna — pilihan: blue, green, amber, red",
          ].join("\n"),
          { parse_mode: "Markdown" }
        );
        session.promptMessageId = nextPrompt.message_id;
        await setSession(env, chatId, session);
        return;
      }
      if (session.action === "update_publish" && session.step === "ask_description") {
        if (!(await requireAdmin(bot, env, chatId, userId))) return;
        const description = text === "-" ? "" : text;
        const { latestVersionCode, latestVersionName, downloadUrl } = session.data;
        const promptMessageId = session.promptMessageId;
        await clearSession(env, chatId);
        try {
          const info = await setUpdateInfo(firestore, {
            latestVersionCode,
            latestVersionName,
            downloadUrl,
            description,
          });
          const notice =
            "Versi baru berhasil dipublish\\! Semua aplikasi Android yang terbuka akan menampilkan dialog update dalam beberapa saat\\.\n\n";
          await resolvePrompt(bot, chatId, promptMessageId, notice + formatUpdateCard(info), {
            parse_mode: "MarkdownV2",
            reply_markup: updateMenuKeyboard(info),
          });
        } catch (err) {
          console.error(err);
          await ctx.reply(`❌ Terjadi error: ${err.message}`);
        }
        return;
      }

      if (session.action === "generate" && session.step === "ask_count") {
        const count = parseInt(text, 10);
        if (!Number.isFinite(count) || count <= 0 || count > MAX_GENERATE_COUNT) {
          await ctx.reply(`Masukkan angka 1-${MAX_GENERATE_COUNT}.`);
          return;
        }
        session.data = { count };
        session.step = "ask_days";
        await setSession(env, chatId, session);
        const nextPrompt = await resolvePrompt(
          bot,
          chatId,
          session.promptMessageId,
          "Berapa hari masa berlaku lisensi ini? (mis. `30`)",
          { parse_mode: "Markdown" }
        );
        session.promptMessageId = nextPrompt.message_id;
        await setSession(env, chatId, session);
        return;
      }
      if (session.action === "generate" && session.step === "ask_days") {
        const days = parseInt(text, 10);
        if (!Number.isFinite(days) || days <= 0) {
          await ctx.reply("Masukkan angka hari yang valid, lebih dari 0.");
          return;
        }
        session.data.days = days;
        session.step = "ask_note";
        await setSession(env, chatId, session);
        const nextPrompt = await resolvePrompt(
          bot,
          chatId,
          session.promptMessageId,
          "Catatan untuk lisensi ini? (opsional, kirim `-` untuk kosongkan)",
          { parse_mode: "Markdown" }
        );
        session.promptMessageId = nextPrompt.message_id;
        await setSession(env, chatId, session);
        return;
      }
      if (session.action === "generate" && session.step === "ask_note") {
        const note = text === "-" ? "" : text;
        const promptMessageId = session.promptMessageId;
        const { count, days } = session.data;
        await clearSession(env, chatId);
        await doGenerate(chatId, count, days, note, promptMessageId);
        return;
      }
    } catch (err) {
      console.error(err);
      await clearSession(env, chatId);
      await ctx.reply(`❌ Terjadi error: ${err.message}`);
    }
  });

  return bot;
}

module.exports = {
  async fetch(request, env, ctx) {
    if (!env.TELEGRAM_BOT_TOKEN) {
      return new Response("TELEGRAM_BOT_TOKEN belum diisi (secret).", { status: 500 });
    }
    if (!env.ADMIN_TELEGRAM_ID) {
      return new Response("ADMIN_TELEGRAM_ID belum diisi (secret/var).", { status: 500 });
    }
    if (!env.FIREBASE_SERVICE_ACCOUNT) {
      return new Response("FIREBASE_SERVICE_ACCOUNT belum diisi (secret).", { status: 500 });
    }
    if (!env.AETHERX_KV) {
      return new Response("KV namespace AETHERX_KV belum di-bind di wrangler.toml.", { status: 500 });
    }

    let bot;
    try {
      bot = createBot(env);
    } catch (err) {
      console.error(err);
      return new Response(`Konfigurasi bot error: ${err.message}`, { status: 500 });
    }

    // grammY memverifikasi header X-Telegram-Bot-Api-Secret-Token secara internal
    // kalau secretToken diisi di sini — otomatis balas 401 kalau tidak cocok/tidak ada,
    // mencegah orang lain mengirim update palsu langsung ke URL worker ini.
    const handleUpdate = webhookCallback(bot, "cloudflare-mod", "throw", 10_000, env.TELEGRAM_WEBHOOK_SECRET);
    return handleUpdate(request);
  },
};
